/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a;
   int b;
   printf("Enter value of a\n");
   scanf("%d",&a);
   printf("Enter value of b\n");
   scanf("%d",&b);
   printf("Sum of numbers %d\n",a+b);
   
   return 0;

    
}
